# EchoSynth Core

Emotion-aware creative AI system that evolves, simulates, and composes based on your linguistic tone and decision intent.

## Run
`python app.py`

## Requirements
See `requirements.txt`
