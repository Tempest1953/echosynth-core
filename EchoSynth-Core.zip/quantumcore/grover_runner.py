# Basic Grover's Algorithm simulation using Qiskit
from qiskit import QuantumCircuit, Aer, execute
from qiskit.circuit.library import GroverOperator
from qiskit.algorithms import Grover
from qiskit.algorithms import AmplificationProblem

def run_grover():
    qc = QuantumCircuit(2)
    qc.cz(0, 1)
    oracle = GroverOperator(qc)

    problem = AmplificationProblem(oracle)
    grover = Grover()
    result = grover.amplify(problem)
    print("🔍 Grover Result:", result)
