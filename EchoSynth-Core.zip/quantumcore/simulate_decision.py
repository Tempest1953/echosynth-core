# Simulates probabilistic decisions using quantum-inspired logic
import random

def simulate_decision(options: list) -> dict:
    weights = {opt: random.randint(10, 100) for opt in options}
    total = sum(weights.values())
    probabilities = {opt: round(weights[opt]/total, 3) for opt in options}
    decision = max(probabilities, key=probabilities.get)

    return {
        "options": options,
        "probabilities": probabilities,
        "chosen": decision
    }
