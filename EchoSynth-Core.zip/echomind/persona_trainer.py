# Builds evolving personality profile based on emotional tone history
from collections import Counter

class PersonaTrainer:
    def __init__(self):
        self.history = []

    def update(self, tone: str):
        self.history.append(tone)

    def summarize(self) -> dict:
        tone_count = Counter(self.history)
        dominant = tone_count.most_common(1)[0][0] if tone_count else "Neutral"
        return {
            "total_interactions": len(self.history),
            "dominant_tone": dominant,
            "tone_breakdown": dict(tone_count)
        }
