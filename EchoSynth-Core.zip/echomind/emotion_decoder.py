# Decodes linguistic patterns into emotional signals + tone categories
class EmotionDecoder:
    def __init__(self):
        self.tones = {
            "BoldVisionary": ["go", "ignite", "launch", "now"],
            "Mythweaver": ["legend", "dream", "cosmic", "echo"],
            "Reflective": ["consider", "maybe", "calm", "balance"],
            "AffirmativeForce": ["yes", "absolutely", "do it"],
        }

    def decode(self, user_input: str) -> str:
        for tone, keywords in self.tones.items():
            if any(word in user_input.lower() for word in keywords):
                return tone
        return "Neutral"
