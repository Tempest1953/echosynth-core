# Converts parsed system blueprint into pseudo-app code scaffold
def generate_code(blueprint: dict) -> str:
    code_lines = [f"# App: {blueprint['name']}", "from flask import Flask", "app = Flask(__name__)"]

    for feature in blueprint["features"]:
        route = feature.replace(" ", "_")
        code_lines.append(f"@app.route('/{route}')\ndef {route}():\n    return '{feature} loaded.'")

    code_lines.append("if __name__ == '__main__':\n    app.run(debug=True)")
    return "\n".join(code_lines)
